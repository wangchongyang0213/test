install step：
openrc.sh:openstack configuration

controller:
iaas-pre-host.sh  iaas-install-mysql.sh iaas-install-keystone.sh iaas-install-glance.sh

controller&compute(controller first compute second):
iaas-install-nova-controller.sh  aas-install-nova-compute.sh  
iaas-install-neutron-controller.sh  aas-install-neutron-compute.sh 

controller:
iaas-install-dashboard.sh  

attention！attention！
If it is executed on a virtual machine, it should be omitted on the server
[root@compute ~]# crudini --set /etc/nova/nova.conf libvirt virt_type  qemu
[root@compute ~]# systemctl restart openstack-nova-compute

[root@controller ~]# crudini --set /etc/nova/nova.conf libvirt virt_type  qemu
[root@controller ~]# systemctl restart openstack-nova*


controller&compute(controller first compute second):
iaas-install-cinder-controller.sh  aas-install-cinder-compute.sh 
iaas-install-swift-controller.sh  aas-install-swift-compute.sh 

Create Network 2 (internal network vlan/vxlan):
Note: In the virtual machine, the default network mode is vxlan, and vlan can be used instead on the server

Because the server is connected to a switch, the interface mode will be set to trunk and vlan will be released. This operation cannot be performed in the virtual machine
To create a vlan network on the server, modify the configuration file:
[root@controller ~]# vim /etc/neutron/plugins/ml2/ml2_conf.ini 
[ml2]
type_drivers = flat,vlan,vxlan
tenant_network_types = vlan

[root@controller ~]# systemctl restart neutron* 


k8s:
iaas-install-zun-controller.sh iaas-install-zun-compute.sh     zun:Openstack Use Zun Provide Serverless
iaas-install-ceilometer-controller.sh iaas-install-ceilometer-compute.sh     ceilometer:Monitoring and measurement services
iaas-install-heat.sh     heat:Heat Resource Scheduling
iaas-install-barbican.sh     barbican:Secrets 
iaas-install-aodh.sh           aodh:Alert Service

